# Desafio Free Fire – Tema 2

Este projeto apresenta uma simulação simples de estratégia para tomada de decisão em uma partida de Free Fire.

## 📌 Objetivo
O código demonstra uma lógica de IA básica que:
- Analisa a distância até o inimigo  
- Verifica os recursos do jogador  
- Escolhe uma ação (atacar, fugir ou procurar loot)

## 🚀 Como executar
1. Instale Python 3.10+  
2. Execute:

```bash
python src/main.py
```

## 📂 Estrutura
```
freefire_project/
│── README.md
└── src/
    └── main.py
```

## 📜 Licença
Uso livre para fins educacionais.
