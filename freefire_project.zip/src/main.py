import random

class Player:
    def __init__(self, health, ammo, distance_to_enemy):
        self.health = health
        self.ammo = ammo
        self.distance_to_enemy = distance_to_enemy

    def decide_action(self):
        if self.health < 30:
            return "Fugir (vida baixa)"
        if self.ammo < 3:
            return "Procurar loot (pouca munição)"
        if self.distance_to_enemy < 20:
            return "Atacar inimigo"
        return "Mover-se com cautela"

def simulate_round():
    health = random.randint(10, 100)
    ammo = random.randint(0, 10)
    distance = random.randint(5, 200)

    player = Player(health, ammo, distance)
    decision = player.decide_action()

    print("=== Simulação de Estratégia Free Fire ===")
    print(f"Vida: {health}")
    print(f"Munição: {ammo}")
    print(f"Distância até o inimigo: {distance}m")
    print(f"Ação tomada: {decision}")

if __name__ == "__main__":
    simulate_round()
